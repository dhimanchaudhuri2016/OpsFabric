# Ops Fabric on Google Cloud Run

This adds a container wrapper to the portable Ops Fabric website. It serves the prebuilt dist folder on port 8080 using unprivileged Nginx. No application build or Node.js process is required inside the container.

Use a Google Cloud project with billing enabled and permission to deploy Cloud Run sources, run Cloud Build, and enable IAP. Deploy in your company-approved region.

Upload this ZIP through Google Cloud Shell's Upload file menu, then run:

```sh
mkdir -p ~/ops-fabric-cloudrun
unzip -o ~/OpsFabric-cloudrun-package.zip -d ~/ops-fabric-cloudrun
cd ~/ops-fabric-cloudrun/OpsFabric
gcloud config set project YOUR_PROJECT_ID
gcloud services enable run.googleapis.com cloudbuild.googleapis.com artifactregistry.googleapis.com iap.googleapis.com
gcloud run deploy ops-fabric --source . --region europe-west2 --port 8080 --no-allow-unauthenticated
```

After deployment, open Cloud Run > ops-fabric > Security. Select Require authentication > Identity-Aware Proxy (IAP), Save, then View diff & redeploy > Deploy changes if shown. The console grants the IAP service agent permission to invoke the service.

Under IAP, Edit policy grants access to selected recognised users/groups. If a role chooser is shown, use IAP-secured Web App User. Being on a bt.com email domain is not by itself a Google identity; BT identity federation or Google-managed identities may be required. Out-of-organisation users can require custom OAuth/consent configuration; use Configure in IAP and ask the company identity administrator to complete it.

Complete access setup before testing the service URL. Private Cloud Run IAM alone does not provide an interactive browser sign-in experience. Test with both an authorised and an unauthorised account. Do not grant allUsers for this restricted deployment.

The core website files match the original portable package. The four BT photos and two fonts remain externally hosted. Read README.md for source editing and SEO URL updates after the final service/custom domain is known.

Google documentation:
- https://docs.cloud.google.com/run/docs/deploying-source-code
- https://docs.cloud.google.com/run/docs/securing/identity-aware-proxy-cloud-run
