# Ops Fabric — portable hosting package

Includes the latest 3D globe, both resilience-game rounds, shot-triggered capability reveals, incident walkthrough, KPI count-up, capability catalogue and feedback.

## Host the ready-built site

1. Extract this ZIP.
2. From this folder, run the command below with your new public address. Include any subfolder in the URL.
3. Upload **the contents of `dist/`** to the host's web root or publish directory. Keep `chunks/`, `thumbnails/` and `licenses/` alongside the other files.
4. Open the new HTTPS address.

```sh
node scripts/configure-host.mjs https://your-domain.example/ops-fabric/
```

This updates the canonical link, Open Graph URLs, structured-data page URL, sitemap and robots.txt. BT's official outbound links remain intact. Relative asset paths support both domain-root and subfolder hosting. Without Node.js, replace the old site address in `dist/index.html`, `dist/robots.txt` and `dist/sitemap.xml` manually.

No production Node.js process, database, API key, ChatGPT hosting or GitHub Pages account is required. Use a static web server that serves `.js` files with a JavaScript MIME type. Opening `index.html` directly from a file manager will not run ES modules correctly.

The default SEO address is the current GitHub website. Change it before publishing at another address. To change the footer package-download link, edit `package_url` in `deployment.json`, then rerun the configure command.

## Edit and rebuild

Use Node.js 18 or newer (22+ recommended), then:

```sh
npm ci
npm run build
```

Edit `public/` for HTML, CSS, images and static SEO files. Edit `src/` for JavaScript and map/network data. The build recreates `dist/` from these folders, bundles JavaScript locally and reapplies `deployment.json`. Source edits survive a rebuild.

For a local preview:

```sh
python3 -m http.server 8080 --directory dist
```

Open http://localhost:8080/ .

## Common hosts

- Netlify / Cloudflare Pages: deploy `dist/` directly, or use build command `npm run build` and output directory `dist` for a source project.
- Vercel: select a static/Other project with output directory `dist`.
- Apache, Nginx, IIS, S3/CDN or another static host: copy `dist/` contents and configure the domain and HTTPS at the host.

Navigation uses section anchors, so no SPA rewrite is needed.

## Assets and feedback

The 3D world, game, incident walkthrough and KPI animation code is bundled locally. Four overview photos and two BT web fonts still load from BT servers. System-font fallbacks are included. Exact URLs are in `EXTERNAL-ASSETS.json`. To host all assets locally, add approved copies and update `public/index.html` and `public/style.css` before rebuilding.

Feedback prepares an email to service.process.adoption@bt.com. The visitor sends it in their email app; Copy feedback is the fallback. There is no submission database. Internal/external choices label feedback rather than restrict access.

## Contents

- `dist/`: ready-to-host website.
- `public/`: editable static page content and assets.
- `src/`: editable immersive experiences and other JavaScript.
- `scripts/`: complete build and new-host URL configuration helpers.
- `package.json`, `package-lock.json`: pinned build dependencies.
- `EXPERIENCES.md`, `THIRD-PARTY-NOTICES.md`, `EXTERNAL-ASSETS.json`: implementation notes, attribution and licences.
- `PACKAGE-MANIFEST.json`: version and file checksums.

The separately created narrated video remains externally hosted; this website package does not contain a downloadable MP4. Current video: https://scrimba.com/explain/guide0lkuv3mk7?fullscreen=1 .
