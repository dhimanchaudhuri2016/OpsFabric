# Third-party notices

Full licence texts are provided in `public/licenses/` and copied into `dist/licenses/`.

- Three.js 0.170.0 and bundled OrbitControls/postprocessing: MIT.
- topojson-client 3.1.0: ISC.
- world-atlas 2.0.2: ISC. Bundled geography derives from Natural Earth public-domain data: https://www.naturalearthdata.com/about/terms-of-use/
- esbuild 0.24.2 (build tool): MIT.

BT fonts, photos, logos and product content retain their original attribution. Four photos and two web fonts load from BT-hosted URLs; see `EXTERNAL-ASSETS.json`.
