import { readFile, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { resolve } from 'node:path';
const root = new URL('../', import.meta.url);
const configFile = new URL('deployment.json', root);
function siteAddress(value) {
  const url = new URL(String(value).trim());
  if (!['https:', 'http:'].includes(url.protocol) || url.username || url.password || url.search || url.hash) {
    throw new Error('Use an HTTP(S) site URL without credentials, a query or a fragment.');
  }
  if (!url.pathname.endsWith('/')) url.pathname += '/';
  return url.href;
}
const escape = value => value.replaceAll('&', '&amp;').replaceAll('"', '&quot;');
export async function configureHost(input) {
  const config = JSON.parse(await readFile(configFile, 'utf8'));
  const site = siteAddress(input || config.site_url);
  config.site_url = site;
  if (config.package_url) siteAddress(config.package_url);
  const social = new URL('social.png', site).href;
  for (const directory of ['public', 'dist']) {
    const indexFile = new URL(directory + '/index.html', root);
    let html;
    try { html = await readFile(indexFile, 'utf8'); }
    catch (error) { if (error.code === 'ENOENT') continue; throw error; }
    html = html.replace(/(<link\b[^>]*rel="canonical"[^>]*href=")[^"]*(")/, (_, a, b) => a + escape(site) + b);
    html = html.replace(/(<meta\b[^>]*property="og:url"[^>]*content=")[^"]*(")/, (_, a, b) => a + escape(site) + b);
    html = html.replace(/(<meta\b[^>]*property="og:image"[^>]*content=")[^"]*(")/, (_, a, b) => a + escape(social) + b);
    html = html.replace(/(<script\b[^>]*type="application\/ld\+json"[^>]*>)([\s\S]*?)(<\/script>)/g, (_, a, body, b) => {
      const data = JSON.parse(body);
      if (data['@type'] === 'WebPage' || data['@type'] === 'WebSite') data.url = site;
      return a + JSON.stringify(data) + b;
    });
    if (config.package_url) html = html.replace(/(<a\b[^>]*href=")[^"]*("[^>]*>Download website package \(ZIP\)<\/a>)/, (_, a, b) => a + escape(config.package_url) + b);
    await writeFile(indexFile, html);
    const robots = new URL(directory + '/robots.txt', root);
    const previous = await readFile(robots, 'utf8');
    const line = 'Sitemap: ' + new URL('sitemap.xml', site).href;
    await writeFile(robots, /^Sitemap:/mi.test(previous) ? previous.replace(/^Sitemap:.*$/mi, line) : previous.trimEnd() + '\n' + line + '\n');
    await writeFile(new URL(directory + '/sitemap.xml', root), '<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"><url><loc>' + escape(site) + '</loc></url></urlset>\n');
  }
  await writeFile(configFile, JSON.stringify(config, null, 2) + '\n');
  console.log('Site URLs configured for ' + site);
}
if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  try { await configureHost(process.argv[2]); }
  catch (error) { console.error(error.message); process.exitCode = 1; }
}
