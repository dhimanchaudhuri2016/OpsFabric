import { cp, mkdir, rm } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { build } from 'esbuild';
import { configureHost } from './configure-host.mjs';
const root = new URL('../', import.meta.url);
const output = new URL('dist/', root);
await rm(output, { recursive: true, force: true });
await mkdir(output, { recursive: true });
await cp(new URL('public/', root), output, { recursive: true });
await build({ absWorkingDir: fileURLToPath(root),
  entryPoints: ['src/experience.js', 'src/arena.js'],
  bundle: true, splitting: true, minify: true, format: 'esm',
  outdir: 'dist', chunkNames: 'chunks/[name]-[hash]' });
await configureHost();
console.log('Build ready: upload the contents of dist/ to your static host.');
